function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-900 via-slate-950 to-emerald-900 flex flex-col items-center justify-center p-6 gap-10">
      <h1 className="text-7xl text-white">AI Interview Coach Starter Code</h1>
    </div>
  );
}

export default App;
